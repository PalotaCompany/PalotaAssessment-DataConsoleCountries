﻿using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Linq;

namespace PalotaInterviewCS
{
    class Program
    {
        private static readonly HttpClient client = new HttpClient();
        private const string countriesEndpoint = "https://restcountries.eu/rest/v2/all";

        static void Main(string[] args)
        {
            Country[] countries = GetCountries(countriesEndpoint).GetAwaiter().GetResult();

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Palota Interview: Country Facts");
            Console.WriteLine();
            Console.ResetColor();

            Random rnd = new Random(); // random to populate fake answer - you can remove this once you use real values

            //TODO use data operations and data structures to optimally find the correct value (N.B. be aware of null values)

            
            /* 
             * Sorted the list in descending order based on Gini coeffecient.
             * and found the position of SouthAfrica's place
             */
            int southAfricanGiniPlace = countries.OrderByDescending(o => o.Gini).ToList().FindIndex(p => p.Name.ToLower() == "south africa");
            Console.WriteLine($"1. South Africa's Gini coefficient is the {GetOrdinal(southAfricanGiniPlace)} highest");

            
             /*
              * Sorted the list in Ascending order based on Gini's coeffecient
              * specifyied not null
              * returned first country name using Country.Name field.
              */
            string lowestGiniCountry = countries.Where(o => o.Gini != null).OrderBy(o => o.Gini).FirstOrDefault()?.Name; // Use correct value
            Console.WriteLine($"2. {lowestGiniCountry} has the lowest Gini Coefficient");

            
             /*
              * Group by Regions
              * Ordered by descending and with most unique time zones
              * Retured first Region with name and Number of time zones
              */
            var region = countries.GroupBy(o => o.Region).OrderByDescending(o => o.Count()).FirstOrDefault();
            string regionWithMostTimezones = region?.Key.ToString(); 
            int amountOfTimezonesInRegion = region.Count(); 
            Console.WriteLine($"3. {regionWithMostTimezones} is the region that spans most timezones at {amountOfTimezonesInRegion} timezones");

           
             /*
              * selected distinct currencies from countries using different currencies and returned number of countries using  each currency
              */

            var distinctCurrencies = countries.SelectMany(o => o.Currencies).Where(o => o.Name != null).GroupBy(o => o.Name).Select(o => o.First()).ToList();
            var currencyPopularity = distinctCurrencies
                .Select(o => new
                {
                    Currency = o,
                    Countries = countries.Where(x => x.Currencies.Any(y => y.Name != null && y.Name.Equals(o.Name))).ToList()
                })
                .OrderByDescending(o => o.Countries.Count).ToList();
            
            var mostPopularCurrency = currencyPopularity.FirstOrDefault(); // Use correct value
            Console.WriteLine($"4. {mostPopularCurrency?.Currency.Name} is the most popular currency and is used in {mostPopularCurrency?.Countries.Count} countries");

            
             /*
              * selected distinct languages from countries using distinct languages and found the number of countries is using each language 
              */
            var distinctLanguages = countries.SelectMany(o => o.Languages).Where(o => o.Name != null).GroupBy(o => o.Name).Select(o => o.First()).ToList();
            var languagePopularity = distinctLanguages
                .Select(o => new
                {
                    Language = o,
                    Countries = countries.Where(x => x.Languages.Any(y => y.Name != null && y.Name.Equals(o.Name))).ToList()
                })
                .OrderByDescending(o => o.Countries.Count).ToList();
            var mostPopularLanguages = languagePopularity.Take(3).Select(o => o.Language.Name).ToList();
            Console.WriteLine($"5. The top three popular languages are {mostPopularLanguages[0]}, {mostPopularLanguages[1]} and {mostPopularLanguages[2]}");

            
             /*
              *calcualted  the sum of population and and bordering countries which have alpha3code
              * ordered by descending 
              * retured first highest combined population with country name and value
             */
            var countryPopulation = countries
               .Select(o => new
               {
                   Country = o,
                   Population = o.Population + countries.Where(x => o.Borders.Contains(x.Alpha3Code)).Sum(x => x.Population)
               })
               .OrderByDescending(o => o.Population).ToList();
            var mostPopulated = countryPopulation.FirstOrDefault();
            Console.WriteLine($"6. {mostPopulated?.Country.Name} and it's {mostPopulated?.Country.Borders.Length} bordering countries has the highest combined population of {mostPopulated?.Population}");

            
            /*
            * calculated the population density of country
            * specified not null
            * ordering by Ascending and retuning first(lowest) density value with country name and value of density
            */
            var countryWithDensity1 = countries.Where(o => o.Area != null).Select(o => new { o.Name, density = o.Population / o.Area.Value }).OrderBy(x => x.density).FirstOrDefault();
            string lowPopDensityName = countryWithDensity1.Name; // Use correct value
            double lowPopDensity = countryWithDensity1.density; // Use correct value
            Console.WriteLine($"7. {lowPopDensityName} has the lowest population density of {lowPopDensity}");

            
             /*
              * calculated the population density of country
              * specified not null
              * ordering by descending and retuning first highest density with country name and value of density
              */
            var countryWithDensity = countries.Where(o => o.Area != null).Select(o => new { o.Name, density = o.Population / o.Area.Value }).OrderByDescending(x => x.density).FirstOrDefault();           
            Console.WriteLine($"8. {countryWithDensity?.Name} has the highest population density of {countryWithDensity?.density}");

            
            /*
             * group by sub regions and sumup the area of sub regions
             * Order by Descending and returning name of subregion with highest area
             */
            var subregionsWithArea = countries.GroupBy(o => o.Subregion).Select(o => new { o.First().Subregion, totArea = o.Sum(k => k.Area) }).OrderByDescending(o => o.totArea).FirstOrDefault();            
            Console.WriteLine($"9. {subregionsWithArea?.Subregion} is the subregion that covers the most area");

            
             /*
              * group by sub regions and calucating average gini coeffecient
              * ordered by Ascending order
              * returned lowest average Gini with sub region name
              */
            var subregionsWithAvgGini = countries.Where(o => o.Gini != null).GroupBy(o => o.Subregion).Select(o => new { o.First().Subregion, avgGini = o.Average(k => k.Gini.Value) }).OrderBy(o => o.avgGini).FirstOrDefault();           
            Console.WriteLine($"10. {subregionsWithAvgGini?.Subregion} is the regional block with the lowest average Gini coefficient of {subregionsWithAvgGini?.avgGini}");

            Console.ReadLine();
        }

        /// <summary>
        /// Gets the countries from a specified endpiny
        /// </summary>
        /// <returns>The countries.</returns>
        /// <param name="path">Path endpoint for the API.</param>
        static async Task<Country[]> GetCountries(string path)
        {
            Country[] countries = null;
            //TODO get data from endpoint and convert it to a typed array using Country.FromJson
            HttpResponseMessage response = await client.GetAsync(path);
            countries = JsonConvert.DeserializeObject<Country[]>(await response.Content.ReadAsStringAsync());
            return countries;
        }

        /// <summary>
        /// Gets the ordinal value of a number (e.g. 1 to 1st)
        /// </summary>
        /// <returns>The ordinal.</returns>
        /// <param name="num">Number.</param>
        public static string GetOrdinal(int num)
        {
            if (num <= 0) return num.ToString();

            switch (num % 100)
            {
                case 11:
                case 12:
                case 13:
                    return num + "th";
            }

            switch (num % 10)
            {
                case 1:
                    return num + "st";
                case 2:
                    return num + "nd";
                case 3:
                    return num + "rd";
                default:
                    return num + "th";
            }

        }
    }
}
